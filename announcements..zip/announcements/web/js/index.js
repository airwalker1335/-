window.addEventListener( "load", function () {

  // Access the form element...
  const form = document.getElementById( "myForm" );

  // ...and take over its submit event.
  form.addEventListener( "submit", function ( event ) {
    event.preventDefault();
	
    getAnnouncements();
  } );
  
  //initialize announcements and professors lists
  getAnnouncements();
  getProfessors();
			
} );


getAnnouncements = function(){
	const XHR = new XMLHttpRequest();

	const pid = document.getElementById( "select" ).value;
	
    // Define what happens in case of error
    XHR.addEventListener( "error", function( event ) {
      alert( 'Oops! Something went wrong.' );
    } );

	// Set up our request
	if(pid>0){
		XHR.open( "GET", "http://localhost/announcements/api/get_announcements.php?pid=" + pid);
	}else{
		//show all
		XHR.open( "GET", "http://localhost/announcements/api/get_announcements.php");
	}

	XHR.setRequestHeader("Content-Type", "application/json");
    XHR.send();
	
	XHR.onreadystatechange = function(){
		if (XHR.readyState == 4){
			if (XHR.status == 200){
				//console.log(XHR.responseText);
				const data = JSON.parse(XHR.responseText);
				show_announcements(data);
			}
		}
	};
}
		
show_announcements = function(data){
	
	const divElem = document.getElementById('result');
	divElem.innerHTML = "";
	for(var i = 0; i < data.length; i++){
		announcement = data[i];
		const pElem = document.createElement('p');
		pElem.innerHTML =  announcement.description + "<br><i>" + announcement.full_name + "<i>";
		divElem.appendChild(pElem);
	}	
}

getProfessors = function(){
	 const XHR = new XMLHttpRequest();
	 // Define what happens in case of error
    XHR.addEventListener( "error", function( event ) {
      alert( 'Oops! Something went wrong.' );
    } );

    // Set up our request
    XHR.open( "GET", "http://localhost/announcements/api/get_professors.php" );
	
	XHR.setRequestHeader("Content-Type", "application/json");
    XHR.send();
	
	XHR.onreadystatechange = function(){
		if (XHR.readyState == 4){
			if (XHR.status == 200){
				//console.log(XHR.responseText);
				const data = JSON.parse(XHR.responseText);
				show_professors(data);
			}
		}
	};
}


show_professors = function(data){
	
	const selElem = document.getElementById('select');
	for(var i = 0; i < data.length; i++){
		prof = data[i];
		const optionElem = document.createElement('option');
		optionElem.value = prof.id;
		optionElem.innerHTML =  prof.full_name;
		selElem.appendChild(optionElem);
	}	
}