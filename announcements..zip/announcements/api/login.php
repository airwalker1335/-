<?php
	
	include_once('db.php');
	$_POST = json_decode(file_get_contents('php://input'), true);
	//print_r($_POST);
	
	$email = $_POST['email'];
	$password = $_POST['password'];
	$query = "SELECT * FROM professors WHERE email = '$email' AND password='$password'";
	
	
	$result = mysqli_query($con, $query) or die("MySQL Error!");
		
	if($row = mysqli_fetch_assoc($result)){
		$data = array('result'=>'ok',
		'id' => $row['id'],
		'email' => $row['email'],
		'full_name' => $row['full_name']
		);
		
	} else { 
		// show error
		$data = array('result'=>'error');
	}
		
	echo json_encode($data);	
	
?>