<?php

include_once('db.php');


$query = "SELECT a.*, p.full_name FROM announcements AS a JOIN professors AS p ON p.id=a.professor_id";

if(isset($_GET["pid"])){
		$query .= " WHERE a.professor_id = ".$_GET["pid"];
}	

$res = mysqli_query($con, $query);

$data = [];
while($row = mysqli_fetch_assoc($res)){
	$data[] = $row;
}

echo json_encode($data);

?>