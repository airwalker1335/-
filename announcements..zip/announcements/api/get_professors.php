<?php

include_once('db.php');

$query = "SELECT * FROM professors";

$res = mysqli_query($con, $query);

$data = [];
while($row = mysqli_fetch_assoc($res)){
	$data[] = $row;
}

echo json_encode($data);

?>