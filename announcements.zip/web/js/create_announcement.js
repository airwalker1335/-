window.addEventListener( "load", function () {
  function sendData() {

	//get professor id from url
	const queryString = window.location.search;
	const urlParams = new URLSearchParams(queryString);
	var id = urlParams.get('id')
	

    const XHR = new XMLHttpRequest();

	const description = document.getElementById( "description" ).value;
	
	const data = {id: id, description: description};
	
    // Define what happens on successful data submission
	
    // Define what happens in case of error
    XHR.addEventListener( "error", function( event ) {
      alert( 'Oops! Something went wrong.' );
    } );

    // Set up our request
    XHR.open( "POST", "http://localhost/announcements/api/post_announcement.php" );
	
	
    // The data sent is what the user provided in the form
	const myJSON = JSON.stringify(data); 
	//console.log(myJSON);
	
	XHR.setRequestHeader("Content-Type", "application/json");
    XHR.send(myJSON);
	
	XHR.onreadystatechange = function(){
		if (XHR.readyState == 4){
			if (XHR.status == 200){
				console.log(XHR.responseText);

				const data = JSON.parse(XHR.responseText);
				console.log(data);
				if(data.result == "ok"){
					//go to index

					alert("Data saved!");
					document.getElementById( "description" ).value = "";
					
				}else{
					alert("Could not save data");
				}
			}
		}
	};
			
 }

  // Access the form element...
  const form = document.getElementById( "myForm" );

  // ...and take over its submit event.
  form.addEventListener( "submit", function ( event ) {
    event.preventDefault();

    sendData();
  } );
} );
		
	
