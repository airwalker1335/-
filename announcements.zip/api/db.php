<?php
$host = 'localhost';
$user='root';
$pass='';
$db = 'announcements';


$con = new mysqli($host, $user, $pass, $db);
if ($con->connect_errno) {
    echo "Failed to connect to MySQL: (" . 
    $con->connect_errno . ") " . $con->connect_error;
}

?>
 
          