<?php

include_once('db.php');
$_POST = json_decode(file_get_contents('php://input'), true);
	
$pid = $_POST["id"];
$descr = $_POST["description"];

$query = "INSERT INTO announcements(professor_id, description) VALUES ($pid, '$descr')";

$res = mysqli_query($con, $query);
if($res){
	$data = array('result'=>'ok'); 
}else{
	$data = array('result'=>'error');
}
echo json_encode($data);

?>